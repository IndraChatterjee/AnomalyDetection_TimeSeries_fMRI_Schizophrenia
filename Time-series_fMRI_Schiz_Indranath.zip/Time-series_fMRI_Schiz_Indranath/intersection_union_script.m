%% Main file

% % By: Indranath Chattterjee
% % Department of computer science, University of Delhi, Delhi-110007,
% % E-mail: indranath.cs.du@gmail.com
% % 
% % This file with load the matrix containing the active regions for healthy 
% % and schizophrenia subjects and do the set operations.


%% Code
% taking intersection. Activations are already calculated and saved in  
% 'activeRegion_healthy_SF3.mat'
% and 'activeRegion_schz_SF3.mat'.

clc;
clear;

% taking intersection of active regions of all healthy subjects
load('activeRegion_healthy_SF3.mat');
activeRegion=activeRegion_healthy_SF3;
a = intersect(activeRegion(1,:),activeRegion(2,:));
for i = 3:34
    a = intersect(a,activeRegion(i,:));
% a = union(a,activeRegion(i,:));
end

% taking intersection of active regions of all schz subjects
load('activeRegion_schz_SF3.mat.mat');
activeRegion=activeRegion_schz_SF3;
b = intersect(activeRegion(1,:),activeRegion(2,:));
for i = 3:34
    b = intersect(b,activeRegion(i,:));
end

% taking union of a and b
index = union(a,b);
index = index(1,2:end);     % leaving 0
% 'index' is ready to use in SVM code