%% Main file
% % 
% % By: Indranath Chattterjee
% % Department of computer science, University of Delhi, Delhi-110007,
% % E-mail: indranath.cs.du@gmail.com
% % 
% % This code will load the contrast maps obtained from GLM analysis on 
% % preprocessed fMRI data of 34 healthy and 34 schizophrenia subjects.
% % The runs or sessions were average and the 3D data was converted 
% % to 1-D vector. The first 34 rows belong to healthy and next 34 belong to
% % schizophrenia. Labels '1' denote healthy and '2' denote the schizophrenia.
% % 
% % This code will run and classify the dataset using Sigmoid kernel ELM 
% % in LOOCV manner where 'n-1' no of sample will be treated as traning set and 1 will be kept for 
% % testing (where 'n' is the total sample). 
% % 
% % The 'index' variable contains the the selected relevant voxels after 
% % set operation in 'intersection_union_script.m' script.
% % 




%% Code
load('Contrast_AudOdd_Dev_Std_15T_2D.mat');
lab = Labels;
rng(5); %   seeding
[indCV]=crossvalind('Kfold',68,68);

X=double(X);
% a=a(1,2:end);
for i=1:68
    
    Xtrain=X(setdiff([1:68],indCV(i)),indexNew);  %fulldata Matrix instance used in prev ttest particular iteration
    %features from chrome which has 1
    labtrain=lab(setdiff([1:68],indCV(i)),:);   %Label from training data used in particular iteration of ttest/
    Xtest=X(indCV(i),indexNew);
    labtest=lab(indCV(i),:);
    
    train_data=cat(2,labtrain,Xtrain);
    test_data=cat(2,labtest,Xtest);
    
    for iter=1:1
        [TrainingTime, TestingTime, TrainingAccuracy, TestingAccuracy] = elm(train_data, test_data, 1, 500, 'sin');
        %[TrainingTime, TestingTime, TrainingAccuracy, TestingAccuracy] = OSELM(train_data, test_data, 1, 500, 'sig', 20, 20);
        testAcc(iter,1)=TestingAccuracy;
    end
    mTestAcc=mean(testAcc);
    accIni(i,1)=mTestAcc;                      %storing accuracy
end
meanAcc=mean(accIni);