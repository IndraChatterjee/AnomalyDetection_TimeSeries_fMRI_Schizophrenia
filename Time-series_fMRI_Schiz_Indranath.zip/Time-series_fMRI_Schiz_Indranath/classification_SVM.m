%% Main file
% % 
% % By: Indranath Chattterjee
% % Department of computer science, University of Delhi, Delhi-110007,
% % E-mail: indranath.cs.du@gmail.com
% % 
% % This code will load the contrast maps obtained from GLM analysis on 
% % preprocessed fMRI data of 34 healthy and 34 schizophrenia subjects.
% % The runs or sessions were average and the 3D data was converted 
% % to 1-D vector. The first 34 rows belong to healthy and next 34 belong to
% % schizophrenia. Labels '1' denote healthy and '2' denote the schizophrenia.
% % 
% % This code will run and classify the dataset using Sigmoid kernel SVM 
% % in LOOCV manner where 'n-1' no of sample will be treated as traning set and 1 will be kept for 
% % testing (where 'n' is the total sample). 
% % 
% % The 'index' variable contains the the selected relevant voxels after 
% % set operation in 'intersection_union_script.m' script.
% % 



%% Code
load('Contrast_AudOdd_Dev_Std_15T_2D.mat');
lab = Labels;
[indCV]=crossvalind('Kfold',68,68);

X=double(X);
% a=a(1,2:end);
for i=1:68
    
    Xtrain=X(setdiff([1:68],indCV(i)),index);  %fulldata Matrix instance used in prev ttest particular iteration
    %features from chrome which has 1
    labtrain=lab(setdiff([1:68],indCV(i)),:);   %Label from training data used in particular iteration of ttest/
    Xtest=X(indCV(i),index);
    labtest=lab(indCV(i),:);
    
    %sigmoid svm
    model = svmtrain(double(labtrain),double(Xtrain),'-t 3 -c 1.09 -q');
    svm_output = svmpredict(double(labtest), double(Xtest),model,'-q');
    
    
    if(labtest == svm_output)
        acc=100;
    else
        acc=0;
    end
    accIni(i,1)=acc;                      %storing accuracy
end
meanAcc=mean(accIni);