%I=load_nii('mask_template/healthy01.hdr'); % 53*63*46
I=load_nii('C:\Users\ducs\Documents\Indra\Research\fMRI\fMRI\fMRI_Dataset_Analysis\FBIRN_FMRI_Expt\Paper7\Data\Healthy\000900369824_49_h_f\AudOdd1\final\swarf0001.hdr');
I.img=zeros(size(I.img));
I1=I.img;
var1=zeros(1582,1); %copy manually only the records of coords which is within GM from talCoordNew File
indexNew=index(1,var1); %1580 out of 2134
VoxInd=sort(indexNew);
I1(VoxInd)=100;
I1(VoxInd)=T(VoxInd); %any ttest results
I.img=I1;

save_nii(I,'result/Vox1582_intersectUnion.img'); % 53*63*46

%% coordinate XYZ finding for value=10 in 53*63*46

[x y z] = ind2sub(size(I1),find(I1~=0));
coords = [x y z];
%coregistered H1_r1_con1.img(source) with T1.img(Reference)
V=spm_vol('mask_template/rT1.nii'); %rT1.nii is the result of coregistration
%V=spm_vol('C:\Users\ducs\Documents\Indra\Research\fMRI\fMRI\fMRI_Dataset_Analysis\FBIRN_FMRI_Expt\Paper7\Data\Healthy\000900369824_49_h_f\AudOdd1\final\swarf0001.hdr');
%T = Rotational Matrix needed for cor2mni.m.
T = V.mat; %(it will give in millimeter coordinate XYZ (+/-))

mni=cor2mni(coords,T);

tal=mni2tal(mni);

% Co-regisrtation of GA_mask (source) with T1 (refe)->rGA_mask (91*109*91)
