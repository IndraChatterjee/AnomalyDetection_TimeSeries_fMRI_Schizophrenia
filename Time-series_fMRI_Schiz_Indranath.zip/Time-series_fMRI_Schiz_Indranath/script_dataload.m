
% % Main file
% % 
% % By: Indranath Chattterjee
% % Department of computer science, University of Delhi, Delhi-110007,
% % E-mail: indranath.cs.du@gmail.com
% % 
% % 1) This program will fetch the time-series fMRI data of each of the 4 runs of 
% % the Auditory-oddball (AUD) task for each of the 34 healthy subjects 
% % and 34 schizophrenia patients. 
% % 
% % 2) This program will try to find the changes in the activation pattern 
% % within a particular voxel along its time-series with the help of 
% % mean-deviation based analysis.
% % 
% % 'Objective': To fetch the dataset and find the changes in activation with
% %             simple statistical anslysis.
% %             
% % 'Input': 4 runs of AUD task fMRI data of 34 schizophrenia and 34 healthy subjects.
% % 
% % 'Output': Matrix file resulting the relevant voxels that show significant changes in 
% %           activation during its time-course for each of the data for both 
% %           healthy and schizophrenia group.
% %           
% % 





%% Loading data from each subject for healthy
clear;
clc;
% path1='C:\Users\ducs\Documents\Indra\Research\fMRI\fMRI\fMRI_Dataset_Analysis\FBIRN_FMRI_Expt\Paper7\Data\Healthy';
path1='C:\Users\ducs\Documents\Indra\Research\fMRI\fMRI\fMRI_Dataset_Analysis\FBIRN_FMRI_Expt\Paper7\Data\Schizophrenic';
list1=dir(path1);   % lists all the files and folders in path1
list1=struct2cell(list1);   %structure to cell array
list2=list1(1,:);   %take only name field
clear list1;
list2=list2(3:end);     %removing root from list
hSub1=zeros(140,153594);
hSubAll=cell(34,1);     %hSubAll is cell array of 34 arrays
activeRegion_schz_SF3=zeros(34,153594);
for sub=1:34
    sub
    path2=strcat(path1,'/',char(list2(sub)),'/AudOdd1/final/swarf0');
    path3=strcat(path1,'/',char(list2(sub)),'/AudOdd2/final/swarf0');
    path4=strcat(path1,'/',char(list2(sub)),'/AudOdd3/final/swarf0');
    path5=strcat(path1,'/',char(list2(sub)),'/AudOdd4/final/swarf0');
    for time=1:140
        if time<10
            file1=strcat(path2,'00',int2str(time),'.img');
            file2=strcat(path3,'00',int2str(time),'.img');
            file3=strcat(path4,'00',int2str(time),'.img');
            file4=strcat(path5,'00',int2str(time),'.img');
        elseif time>=10 && time<100
            file1=strcat(path2,'0',int2str(time),'.img');
            file2=strcat(path3,'0',int2str(time),'.img');
            file3=strcat(path4,'0',int2str(time),'.img');
            file4=strcat(path5,'0',int2str(time),'.img');
        else
            file1=strcat(path2,int2str(time),'.img');
            file2=strcat(path3,int2str(time),'.img');
            file3=strcat(path4,int2str(time),'.img');
            file4=strcat(path5,int2str(time),'.img');
        end
        f1=load_nii(file1);
        f2=load_nii(file2);
        f3=load_nii(file3);
        f4=load_nii(file4);
        f1=(f1.img);
        f2=(f2.img);
        f3=(f3.img);
        f4=(f4.img);
        f1=f1(:)';
        f2=f2(:)';
        f3=f3(:)';
        f4=f4(:)';
        hSub1(time,:)=(f1+f2+f3+f4)/4;
        clear f1 file1;
        clear f2 file2;
        clear f3 file3;
        clear f4 file4;
    end
    count=0;
    for i=1:153594
        if mod(i,10000) == 0
            i
        end
        mVal = mean(hSub1(:,i)); %finding mean of each timeseries
        aDev = abs(hSub1(:,i) - mVal); %finding absolute deviation, substracting mean value from each datapoint
        med = median(aDev); %finding median of AbsDeviation values
        constVal = 3; %taking factor as 7, if increases, no of outliers decreases
        thresVal = constVal * med; %threshold value calculation
        outlier = abs(aDev) > thresVal; %if the val is greater than threshold, then outlier
        flag = 0;
        for j=1:140
            if outlier(j) ~= 0
                flag = 1;
            end
        end
        if flag == 1
            count = count +1;
            %activeRegion = contains the index of the outlier/voxel for each subject
            %across the time series
            activeRegion_schz_SF3(sub, count) = i; %Change to _S for Schiz and SF for sensitivity factor
        end
        
    end
end   


